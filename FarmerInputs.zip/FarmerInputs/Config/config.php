<?php

return [
    'name' => 'FarmerInputs',
];
